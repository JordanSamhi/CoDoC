package de.fraunhofer.sit.sse.sourcesinkeval;

import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import javax.xml.stream.XMLStreamException;

import org.apache.commons.io.FileUtils;

import de.codeinspect.collections.CountingMap;
import heros.solver.Pair;
import soot.jimple.infoflow.results.xml.InfoflowResultsReader;
import soot.jimple.infoflow.results.xml.SerializedInfoflowResults;
import soot.jimple.infoflow.results.xml.SerializedSinkInfo;
import soot.jimple.infoflow.results.xml.SerializedSourceInfo;

/**
 * Utility for analyzing sources and sinks that appear in data flows
 * 
 * @author Steven Arzt
 *
 */
public class MainClass {

	public static void main(String[] args) throws XMLStreamException, IOException {
		int allSinks = 0;
		int allSources = 0;
		CountingMap<String> sinkCounts = new CountingMap<>();
		CountingMap<String> sourceCounts = new CountingMap<>();

		List<String> excludedSources = null;
		List<String> excludedSinks = null;
		if (args.length > 1) {
			excludedSources = FileUtils.readLines(new File(args[1]), "UTF-8");
			excludedSinks = FileUtils.readLines(new File(args[2]), "UTF-8");
		}

		for (File f : new File(args[0]).listFiles(new FilenameFilter() {

			@Override
			public boolean accept(File dir, String name) {
				return name.toLowerCase().endsWith(".apk");
			}

		})) {
			// Read the results file
			InfoflowResultsReader rdr = new InfoflowResultsReader();
//			System.out.println(String.format("Loading file %s...", f.getAbsolutePath()));
			try {
				SerializedInfoflowResults results = rdr.readResults(f.getAbsolutePath());

				// Print the sources and sinks
				for (SerializedSinkInfo sink : results.getResults().keySet()) {
					String sinkMethod = getMethod(sink.getStatement());
					if (excludedSinks == null || !excludedSinks.contains(sinkMethod))
						sinkCounts.increment(sinkMethod);
					allSinks++;

					for (SerializedSourceInfo source : results.getResults().get(sink)) {
						String sourceMethod = getMethod(source.getStatement());
						if (excludedSources == null || !excludedSources.contains(sourceMethod))
							sourceCounts.increment(sourceMethod);
						allSources++;
					}
				}
			} catch (XMLStreamException ex) {
				System.err.println(String.format("Could not read file %s", f));
			}
		}

		System.out.println(String.format("We have %d sources and %d sinks", allSources, allSinks));

		System.out.println("================ SOURCES ================");
		prettyPrintMap(sort(sourceCounts));
		System.out.println("================ SINKS ================");
		prettyPrintMap(sort(sinkCounts));
	}

	/**
	 * Prints the given map in readable form
	 * 
	 * @param map The map to print
	 */
	private static void prettyPrintMap(List<Pair<String, Integer>> map) {
		for (Pair<String, Integer> pair : map) {
			System.out.println(pair.getO2() + "\t" + pair.getO1());
		}
	}

	/**
	 * Sorts this counting map such that the element associated with the highest
	 * value comes first
	 * 
	 * @return A sorted list of elements from this map
	 */
	public static List<Pair<String, Integer>> sort(CountingMap<String> map) {
		return map.entrySet().stream().map(e -> new Pair<String, Integer>(e.getKey(), e.getValue()))
				.sorted((e1, e2) -> e2.getO2() - e1.getO2()).collect(Collectors.toList());
	}

	/**
	 * Prints the given map in readable form
	 * 
	 * @param map The map to print
	 */
	private static void prettyPrintMap(CountingMap<String> map) {
		for (String str : map.keySet())
			System.out.println(map.get(str) + "\t" + str);
	}

	/**
	 * Gets the method that is invoked in the given statement
	 * 
	 * @param statement The statement
	 * @return The method that is invoked in the statement
	 */
	private static String getMethod(String statement) {
		Pattern p = Pattern.compile("(?<method>\\<.+\\>)");
		Matcher m = p.matcher(statement);
		m.find();
		return m.group("method");
	}

}
